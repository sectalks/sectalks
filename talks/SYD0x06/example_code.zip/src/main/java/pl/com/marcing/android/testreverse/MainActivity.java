package pl.com.marcing.android.testreverse;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;


public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText pass = (EditText) findViewById(R.id.editText);
        final TextView textView = (TextView) findViewById(R.id.textView2);
        Button login = (Button) findViewById(R.id.button);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String password = pass.getText().toString();

                if(isPassCorrect(password)) {
                    Toast.makeText(MainActivity.this, "Correct!",
                            Toast.LENGTH_LONG).show();
                    textView.setTextColor(Color.GREEN);
                    textView.setText("CORRECT!");
                } else {
                    Toast.makeText(MainActivity.this, "Maybe next time...",
                            Toast.LENGTH_LONG).show();
                    textView.setTextColor(Color.RED);
                    textView.setText("MAYBE NEXT TIME!");
                }
            }
        });
    }

    private boolean isPassCorrect(String password) {
        //generate random password
        final String correctPass = getRandomString(8);
        //check if user guessed correct
        return correctPass.equals(password);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private static final String ALLOWED_CHARACTERS = "0123456789qwertyuiopasdfghjklzxcvbnm";

    private String getRandomString(final int sizeOfRandomString) {
        final Random random = new Random();
        final StringBuilder sb = new StringBuilder(sizeOfRandomString);
        for (int i = 0; i < sizeOfRandomString; ++i) {
            sb.append(ALLOWED_CHARACTERS.charAt(random.nextInt(ALLOWED_CHARACTERS.length())));
        }
        return sb.toString();
    }
}
