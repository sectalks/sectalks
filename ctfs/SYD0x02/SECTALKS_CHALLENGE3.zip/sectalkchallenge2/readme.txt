This challenge has been compiled from the following resources:

https://gist.github.com/borismus/1032746
http://blog.engelke.com/2014/08/23/public-key-cryptography-in-the-browser/
http://blog.engelke.com/2014/07/16/symmetric-cryptography-in-the-browser-conclusion/
http://nick.bleeken.eu/demos/web-crypto-samples/
https://developer.mozilla.org/en-US/docs/Web/API/Window.crypto
http://www.snip2code.com/Snippet/174395/Web-Crypto-API-example
https://timtaubert.de/blog/2014/10/keeping-secrets-with-javascript/
and lots of random code from Stackoverflow.

Fake content is from clashofclans.wikia.com/wiki/Clash_of_Clans_Wiki
